<!DOCTYPE html>
<html lang="en">
<head>
<title>CAT GIRL</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Major - 5* Hotel template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../styles/bootstrap-4.1.2/bootstrap.min.css">
<link href="../plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="../plugins/OwlCarousel2-2.2.1/animate.css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="../styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="../styles/responsive.css">
</head>
<body>

<div class="super_container">
	
	<!-- Header -->
	<header class="header">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="header_content d-flex flex-row align-items-center justify-content-start">
						<div class="logo">
							<a href="#">
								<div>Cat Girl</div>
								<div>Your Genetically Engineered Catgirls</div>
							</a>
						</div>
						<nav class="main_nav">
							<ul class="d-flex flex-row align-items-center justify-content-start">
								<li class="active"><a href="index.html">Home</a></li>
								<li><a href="http://localhost/catgirls/index.php/catgirls">About us</a></li>
								<li><a href="http://localhost/catgirls/index.php/catgirls">Cat Girls</a></li>
								<li><a href="http://localhost/catgirls/index.php/catgirls">News</a></li>
								<li><a href="http://localhost/catgirls/index.php/catgirls">Contact</a></li>
							</ul>
						</nav>
						<div class="header_extra d-flex flex-row align-items-center justify-content-start ml-auto">
							<div class="phone d-flex flex-row align-items-center justify-content-start"><i class="fa fa-phone" aria-hidden="true"></i><span>+123 456 789</span></div>
							<div class="book_button trans_200"><a href="#">Order Now</a></div>
						</div>
						<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<!-- Home -->

	<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="../images/CatGirls.jpg" data-speed="0.8"></div>
		<div class="home_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="home_content text-center">
							<div class="home_title"><h1>Cuteness</h1></div>
							<div class="home_text">A catgirl (nekomimi: 猫耳, literally cat ear[s]) is a female character with cat traits, such as cat ears, a cat tail, or other feline characteristics on an otherwise human body. Catgirls are found in various fiction genres and in particular Japanese anime and manga.</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Search Box -->

	<div class="search_box">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="search_box_container d-flex flex-row align-items-center justify-content-start">
						<div class="search_form_container">
							<form action="#" id="search_form" class="search_form">
								<div class="d-flex flex-lg-row flex-column align-items-center justify-content-start">
									<ul class="search_form_list d-flex flex-row align-items-center justify-content-start flex-wrap">
										<li class="search_dropdown d-flex flex-row align-items-center justify-content-start">
											<span>CatGirl Ears Color</span>
											<i class="fa fa-chevron-down ml-auto" aria-hidden="true"></i>
											<ul>
												<li>Black</li>
												<li>White</li>
												<li>Brown</li>
												<li>Custom</li>
											</ul>
										</li>
										<li class="search_dropdown d-flex flex-row align-items-center justify-content-start">
											<span>CatGirl Tail Color</span>
											<i class="fa fa-chevron-down ml-auto" aria-hidden="true"></i>
											<ul>
												<li>Black</li>
												<li>White</li>
												<li>Brown</li>
												<li>Custom</li>
											</ul>
										</li>
										<li class="search_dropdown d-flex flex-row align-items-center justify-content-start">
											<span>Age</span>
											<i class="fa fa-chevron-down ml-auto" aria-hidden="true"></i>
											<ul>
												<li>9-15</li>
												<li>16-18</li>
												<li>19-21</li>
												<li>22-25</li>
												<li>26-30</li>
												<li>Custom</li>
											</ul>
										</li>
										<li class="search_dropdown d-flex flex-row align-items-center justify-content-start">
											<span>Skin Color</span>
											<i class="fa fa-chevron-down ml-auto" aria-hidden="true"></i>
											<ul>
												<li>Black</li>
												<li>White</li>
												<li>Brown</li>
												<li>Custom</li>
											</ul>
										</li>
										<li class="search_dropdown d-flex flex-row align-items-center justify-content-start">
											<span>3 Size</span>
											<i class="fa fa-chevron-down ml-auto" aria-hidden="true"></i>
											<ul>
												<li>Custom</li>
											</ul>
										</li>
									</ul>
									<button class="search_button">search</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Intro -->

	<div class="intro">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<div class="section_title"><h1>Why Cat Girls ?</h1></div>
						<div class="section_text">Because catgirls combine attractiveness of a woman with cuteness of a cat. Or with a ferocity of a big cat.</div>
					</div>
				</div>
			</div>
			<div class="row intro_row">
				
				<!-- Intro Image -->
				<div class="col-lg-6">
					<div class="intro_image"><img src="../images/CatGirls2.gif" alt="https://unsplash.com/@papao03"></div>
				</div>

				<!-- Intro Content -->
				<div class="col-lg-6 intro_col">
					<div class="intro_content">
						<div class="quote"><img src="../images/quote.png" alt=""></div>
						<div class="intro_text">
							<p>This World Need Genetically Engineered Catgirls</p>
						</div>
						<div class="intro_author d-flex flex-row align-items-center justify-content-start">
							<div class="intro_author_content">
								<div class="intro_author_name">Sora</div>
								<div class="intro_author_title">Master Dev</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Room=Catgirls -->

	<div class="room d-flex flex-lg-row flex-column align-items-start justify-content-start">
		<div class="room_content">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="room_title">
							<div class="section_title_container_2">
								<div class="section_title"><h1>Chocola</h1></div>
							</div>
							<div class="room_price">From <span>$1900</span></div>
						</div>
						<div class="room_list">
							<ul>
								<li class="d-flex flex-row align-items-start justify-content-start">
									<div><div>Ears Color</div></div>
									<div>Brown</div>
								</li>
								<li class="d-flex flex-row align-items-start justify-content-start">
									<div><div>Tail Color:</div></div>
									<div>Brown</div>
								</li>
								<li class="d-flex flex-row align-items-start justify-content-start">
									<div><div>Age:</div></div>
									<div>9</div>
								</li>
								<li class="d-flex flex-row align-items-start justify-content-start">
									<div><div>Skin Color:</div></div>
									<div>White</div>
								</li>
								<li class="d-flex flex-row align-items-start justify-content-start">
									<div><div>3 Size:</div></div>
									<div>75cm, 54cm, 76cm</div>
								</li>
							</ul>
						</div>
						<div class="button room_button trans_200"><a href="#">Buy Now</a></div>
					</div>
				</div>
			</div>		
		</div>
		<div class="room_image">
			<div class="background_image" style="background-image:url(../images/Chocola.png)"></div>
		</div>
	</div>
	
	<br>
	<br>
	<br>	

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="footer_content d-flex flex-md-row flex-column align-items-center align-items-start justify-content-start">
						<div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="footer_logo">
							<div class="logo">
								<a href="#">
									<div>Major</div>
									<div>5 * Hotel</div>
								</a>
							</div>
						</div>
						<div class="button footer_button ml-md-auto"><a href="#">book now</a></div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../styles/bootstrap-4.1.2/popper.js"></script>
<script src="../styles/bootstrap-4.1.2/bootstrap.min.js"></script>
<script src="../plugins/greensock/TweenMax.min.js"></script>
<script src="../plugins/greensock/TimelineMax.min.js"></script>
<script src="../plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="../plugins/greensock/animation.gsap.min.js"></script>
<script src="../plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="../plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="../plugins/easing/easing.js"></script>
<script src="../plugins/progressbar/progressbar.min.js"></script>
<script src="../plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="../plugins/parallax-js-master/parallax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
<script src="../js/custom.js"></script>
</body>
</html>